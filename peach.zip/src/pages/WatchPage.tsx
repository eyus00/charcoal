import React, { useState, useEffect } from 'react';
import { useParams, useSearchParams, useNavigate } from 'react-router-dom';
import { useMedia } from '../api/hooks/useMedia';
import { SOURCES, getMovieUrl, getTvUrl } from '../lib/sources';
import { useWatchTracking } from '../hooks/useWatchTracking';
import { useStore } from '../store/useStore';
import { useQueries } from '@tanstack/react-query';
import { mediaService } from '../api/services/media';
import { cn } from '../lib/utils';
import CustomPlayer from '../components/watch/CustomPlayer';
import BottomBar from '../components/watch/BottomBar';
import { streamClient } from '../api/streamClient';

const WatchPage: React.FC = () => {
  const { mediaType, id } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const season = searchParams.get('season');
  const episode = searchParams.get('episode');
  const [selectedSource, setSelectedSource] = useState(SOURCES[0].id);
  const [selectedSeason, setSelectedSeason] = useState(Number(season) || 1);
  const [isLandscape, setIsLandscape] = useState(false);
  const [useCustomPlayer, setUseCustomPlayer] = useState(true);
  const [streamData, setStreamData] = useState<any>(null);
  const [isLoadingStream, setIsLoadingStream] = useState(false);
  const [streamError, setStreamError] = useState<string | null>(null);

  const { addToWatchHistory, updateWatchlistStatus } = useStore();

  useEffect(() => {
    const checkOrientation = () => {
      setIsLandscape(window.innerWidth > window.innerHeight);
    };

    checkOrientation();
    window.addEventListener('resize', checkOrientation);
    window.addEventListener('orientationchange', checkOrientation);

    return () => {
      window.removeEventListener('resize', checkOrientation);
      window.removeEventListener('orientationchange', checkOrientation);
    };
  }, []);

  // Fetch streams from custom server
  useEffect(() => {
    const fetchStreams = async () => {
      if (!id || !mediaType) return;

      setIsLoadingStream(true);
      setStreamError(null);

      try {
        const response = await streamClient.getStream(
          Number(id),
          mediaType as 'movie' | 'tv',
          mediaType === 'tv' ? Number(season) : undefined,
          mediaType === 'tv' ? Number(episode) : undefined,
          'auto'
        );

        if (response.success && response.data) {
          setStreamData(response.data);
          setUseCustomPlayer(true);
        } else {
          // Fallback to old player if custom server fails
          console.warn('Stream fetch failed, falling back to embedded players:', response.error);
          setStreamError(response.error);
          setUseCustomPlayer(false);
        }
      } catch (error) {
        console.error('Failed to fetch streams:', error);
        setStreamError('Failed to fetch streams. Using embedded player.');
        setUseCustomPlayer(false);
      } finally {
        setIsLoadingStream(false);
      }
    };

    fetchStreams();
  }, [id, mediaType, season, episode]);

  const { data: details } = useMedia.useDetails(
    mediaType as 'movie' | 'tv',
    Number(id)
  );

  const seasonQueries = useQueries({
    queries: (details?.seasons ?? []).map(season => ({
      queryKey: ['season', id, season.season_number],
      queryFn: () => mediaService.getTVSeasonDetails(Number(id), season.season_number),
      enabled: !!details && mediaType === 'tv'
    }))
  });

  const seasons = seasonQueries
    .filter(query => query.data)
    .map(query => query.data);

  useWatchTracking({
    mediaType,
    id: Number(id),
    title: mediaType === 'movie' ? details?.title : details?.name,
    posterPath: details?.poster_path,
    season,
    episode,
    onAddToHistory: addToWatchHistory,
    onUpdateWatchlist: updateWatchlistStatus,
  });

  // Use custom player if stream data is available, otherwise use embedded players
  const videoUrl = !useCustomPlayer
    ? (mediaType === 'movie'
      ? getMovieUrl(selectedSource, Number(id))
      : getTvUrl(selectedSource, Number(id), Number(season), Number(episode)))
    : streamData?.qualities[0]?.url;

  if (!videoUrl && !isLoadingStream) {
    return <div className="w-full h-full flex items-center justify-center bg-black text-white">Invalid media type or missing parameters</div>;
  }

  const backUrl = mediaType === 'movie' ? `/movie/${id}` : `/tv/${id}`;

  const handlePrevious = () => {
    if (mediaType === 'tv' && episode && season) {
      if (Number(episode) > 1) {
        navigate(`/watch/tv/${id}?season=${season}&episode=${Number(episode) - 1}`);
      } else if (Number(season) > 1) {
        navigate(`/watch/tv/${id}?season=${Number(season) - 1}&episode=1`);
      }
    }
  };

  const handleNext = () => {
    if (mediaType === 'tv' && episode && season) {
      const currentSeason = seasons?.find(s => s.season_number === Number(season));
      if (Number(episode) < (currentSeason?.episodes?.length || 0)) {
        navigate(`/watch/tv/${id}?season=${season}&episode=${Number(episode) + 1}`);
      } else if (Number(season) < (details?.number_of_seasons || 0)) {
        navigate(`/watch/tv/${id}?season=${Number(season) + 1}&episode=1`);
      }
    }
  };

  const handleEpisodeSelect = (season: number, episode: number) => {
    navigate(`/watch/tv/${id}?season=${season}&episode=${episode}`);
  };

  const currentSeasonData = seasons?.find(s => s.season_number === selectedSeason);
  const currentEpisodeData = currentSeasonData?.episodes.find(e => e.episode_number === Number(episode));

  const isFirstEpisode = Number(season) === 1 && Number(episode) === 1;
  const isLastEpisode = Number(season) === seasons?.length && Number(episode) === currentSeasonData?.episodes.length;

  const handlePlayerProgress = (progress: number, duration: number) => {
    // This is called by CustomPlayer, progress tracking is handled by useWatchTracking hook
  };

  const handlePlayerEnded = () => {
    // Auto-play next episode for TV shows
    if (mediaType === 'tv' && episode && season) {
      handleNext();
    }
  };

  return (
    <div className={cn(
      "fixed inset-0 flex flex-col bg-black",
      isLandscape && "flex-col-reverse"
    )}>
      <div className="relative flex-1">
        {isLoadingStream ? (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500" />
          </div>
        ) : useCustomPlayer && streamData && videoUrl ? (
          <CustomPlayer
            streamUrl={videoUrl}
            qualities={streamData.qualities}
            captions={streamData.captions}
            title={mediaType === 'movie' ? details?.title : details?.name}
            poster={details?.poster_path ? `https://image.tmdb.org/t/p/w500${details.poster_path}` : undefined}
            onProgress={handlePlayerProgress}
            onEnded={handlePlayerEnded}
          />
        ) : (
          // Fallback to embedded player
          <div className="absolute inset-0">
            <iframe
              key={videoUrl}
              src={videoUrl}
              className="w-full h-full"
              allowFullScreen
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            />
          </div>
        )}
      </div>
      <BottomBar
        onBack={() => navigate(backUrl)}
        backUrl={backUrl}
        onPrevious={handlePrevious}
        onNext={handleNext}
        onSourceChange={setSelectedSource}
        selectedSource={selectedSource}
        showTitle={mediaType === 'movie' ? details?.title : details?.name}
        episodeTitle={currentEpisodeData?.name}
        seasons={seasons}
        currentSeason={season}
        currentEpisode={episode}
        selectedSeason={selectedSeason}
        onSeasonChange={setSelectedSeason}
        onEpisodeSelect={handleEpisodeSelect}
        isFirstEpisode={isFirstEpisode}
        isLastEpisode={isLastEpisode}
        tvId={Number(id)}
        isMovie={mediaType === 'movie'}
        isLandscape={isLandscape}
      />
    </div>
  );
};

export default WatchPage;
