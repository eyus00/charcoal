export const apiBaseUrl = 'https://borg.rips.cc';

export const username = '_sf_'; // I'd appreciate if you made your own account "_sf_" seems to be removed. Invite codes are: fmhy or mpgh

export const password = 'defonotscraping';
