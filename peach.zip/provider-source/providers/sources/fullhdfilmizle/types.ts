export interface PackerParams {
  payload: string; // p
  radix: number; // a
  count: number; // c
  keywords: string[]; // k
}
