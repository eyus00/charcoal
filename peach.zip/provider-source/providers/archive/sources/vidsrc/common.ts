export const vidsrcBase = 'https://vidsrc.me';
export const vidsrcRCPBase = 'https://vidsrc.stream';
