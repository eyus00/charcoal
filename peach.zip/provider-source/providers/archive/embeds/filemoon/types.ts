export type SubtitleResult = {
  file: string;
  label: string;
  kind: string;
}[];
